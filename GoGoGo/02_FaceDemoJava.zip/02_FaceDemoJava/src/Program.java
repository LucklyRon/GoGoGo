import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONObject;

import com.baidu.aip.face.AipFace;


public class Program {

	//����APPID/AK/SK
    public static final String APP_ID = "9407539";
    public static final String API_KEY = "2iIZGfGttr7ps2GZ1DUXC8N1";
    public static final String SECRET_KEY = "va1Yn0HUOk1iLs2SWn9PZGe8bTPzIzor";

	public static void main(String[] args) {
		


        // ��ʼ��һ��FaceClient
        AipFace client = new AipFace(APP_ID, API_KEY, SECRET_KEY);

        // ��ѡ�������������Ӳ���
        client.setConnectionTimeoutInMillis(2000);
        client.setSocketTimeoutInMillis(60000);

        //facesetAddUser(client);
        //getUser(client,"zjl1");
        identifyUser(client);
	}

	public static void facesetAddUser(AipFace client) {
	    // ����Ϊ����ͼƬ·��
	    String path1 = "D:/_HelloWorld/01_MyProjects/27_AI/Face/photo/zjl/zjl1.jpg";
	    ArrayList<String> path = new ArrayList<String>();
	    path.add(path1);
	    JSONObject res = client.addUser("zjl1", "zjl1", "group1", path);
	    System.out.println(res.toString(2));
	}
	
	public static void getUser(AipFace client,String uid) {
	    JSONObject res = client.getUser(uid);
	    System.out.println(res.toString(2));
	}
	
	//����ʶ��
	//����ʶ��ӿ����ڼ���ָ�������û����ϴ�ͼ������ƶȡ�
	//������Ҫ����һЩͼƬ��ָ�����ڸ��û����ƶȣ�
	public static void identifyUser(AipFace client) {
		String path1 = "D:/_HelloWorld/01_MyProjects/27_AI/Face/photo/zjl/zjl1.jpg";
	    String path2 = "D:/_HelloWorld/01_MyProjects/27_AI/Face/photo/zjl/zjl2.jpg";
	    String path3 = "D:/_HelloWorld/01_MyProjects/27_AI/Face/photo/zjl/zjl3.jpg";
	    ArrayList<String> path = new ArrayList<String>();
	    path.add(path1);
	    path.add(path2);
	    path.add(path3);
	    HashMap<String, Object> options = new HashMap<String, Object>(1);
	    options.put("user_top_num", path.size());
	    options.put("face_top_num", 10);
	    JSONObject res = client.identifyUser("group1", path, options);
	    System.out.println(res.toString(2));
	}
}
